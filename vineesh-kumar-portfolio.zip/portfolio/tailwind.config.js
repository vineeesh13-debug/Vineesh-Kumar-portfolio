/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Base surfaces — near-black with a deliberate blue cast,
        // distinct from a flat #000 background.
        base: "#0A0E14",
        panel: "#0F1521",
        "panel-raised": "#141B29",
        border: "#1C2433",
        "border-soft": "#161D2B",
        // Text
        ink: "#E8EAED",
        "ink-muted": "#8B96A8",
        "ink-faint": "#5A6478",
        // Signature accent — cool teal (data/terminal), not violet-AI default
        signal: "#5EEAD4",
        "signal-dim": "#2DD4BF",
        // Sparing warm accent for highlights / "active" markers
        amber: "#F59E0B",
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      backgroundImage: {
        "grid-pattern":
          "linear-gradient(to right, #1C2433 1px, transparent 1px), linear-gradient(to bottom, #1C2433 1px, transparent 1px)",
      },
      animation: {
        "pulse-slow": "pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        flow: "flow 2.5s linear infinite",
      },
      keyframes: {
        flow: {
          "0%": { strokeDashoffset: "24" },
          "100%": { strokeDashoffset: "0" },
        },
      },
    },
  },
  plugins: [],
};
