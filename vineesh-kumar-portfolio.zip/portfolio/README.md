# Vineesh Kumar — Portfolio

A premium, recruiter-focused portfolio site for an AI/ML/Data Engineer,
built with Next.js 15, React, TypeScript, Tailwind CSS, and Framer Motion.

All content (experience, skills, education, projects) is sourced directly
from the uploaded resume — nothing is fabricated. See `src/lib/data.ts`
for the single source of truth; edit that file to update site content.

---

## 1. Folder structure

```
portfolio/
├── public/
│   └── resume/
│       └── Vineesh-Kumar-Resume.docx   # downloadable resume (swap for a PDF anytime)
├── src/
│   ├── app/
│   │   ├── layout.tsx        # root layout: fonts, SEO metadata, Open Graph, JSON-LD
│   │   ├── page.tsx          # assembles all sections in order
│   │   ├── globals.css       # design tokens, base styles, signature animation utilities
│   │   ├── not-found.tsx     # custom 404
│   │   ├── robots.ts         # robots.txt route
│   │   └── sitemap.ts        # sitemap.xml route
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Navbar.tsx    # sticky nav, mobile menu
│   │   │   └── Footer.tsx
│   │   ├── sections/
│   │   │   ├── Hero.tsx
│   │   │   ├── About.tsx
│   │   │   ├── Skills.tsx
│   │   │   ├── Experience.tsx
│   │   │   ├── Projects.tsx
│   │   │   ├── Education.tsx     # also renders Certifications
│   │   │   └── Contact.tsx
│   │   └── ui/
│   │       ├── Button.tsx        # shared link/button control
│   │       ├── SectionHeading.tsx
│   │       └── FlowRail.tsx      # signature animated pipeline connector
│   └── lib/
│       ├── data.ts           # ⭐ single source of truth for all resume content
│       └── utils.ts          # className helper
├── tailwind.config.js        # design tokens (colors, fonts, animations)
├── next.config.js
├── tsconfig.json
└── package.json
```

---

## 2. Installation

Requires **Node.js 18.18+** (Node 20 LTS recommended) and npm.

```bash
# 1. Install dependencies
npm install

# 2. Run the dev server
npm run dev

# 3. Open http://localhost:3000
```

Other scripts:

```bash
npm run build   # production build
npm run start   # serve the production build locally
npm run lint    # ESLint
```

### Updating content

Everything recruiter-facing lives in **`src/lib/data.ts`**:
`profile`, `about`, `skillCategories`, `experience`, `projects`,
`education`, `certifications`. Edit the arrays/objects there — every
section component reads from this file, so content stays consistent
across the whole site with one edit.

### Swapping the resume file

Replace `public/resume/Vineesh-Kumar-Resume.docx` with a PDF (recommended —
PDFs render consistently across devices) and update `profile.resumeFile`
in `src/lib/data.ts` to match the new filename/extension.

### Certifications

The source resume didn't list a certifications section, so
`certifications` in `data.ts` starts as an empty array and the site
shows a clean "in progress" state instead of inventing credentials. Add
real entries as you earn them:

```ts
export const certifications: Certification[] = [
  {
    id: "aws-saa",
    name: "AWS Certified Solutions Architect – Associate",
    issuer: "Amazon Web Services",
    year: "2026",
    credentialUrl: "https://www.credly.com/...",
  },
];
```

---

## 3. Deployment to Vercel

### Option A — Vercel CLI

```bash
npm install -g vercel
vercel login
vercel          # first deploy, follow prompts
vercel --prod   # promote to production
```

### Option B — Git-based deploy (recommended for ongoing updates)

1. Push this project to a GitHub repository.
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo.
3. Vercel auto-detects Next.js — no config needed. Click **Deploy**.
4. Every push to `main` redeploys automatically; PRs get preview URLs.

### Custom domain

In the Vercel project → **Settings → Domains**, add your domain (e.g.
`vineeshkumar.dev`) and follow the DNS instructions. Once attached,
update the `siteUrl` constant in `src/app/layout.tsx` and the URLs in
`src/app/robots.ts` / `src/app/sitemap.ts` to match.

### Open Graph image

Add a real `og-image.png` (1200×630) to `/public` — the metadata in
`layout.tsx` already references `/og-image.png`. Until it's added,
social sharing previews will fall back to a blank/default image.

---

## 4. Suggestions for improving recruiter visibility

1. **Custom domain + real OG image.** A branded domain (firstname-lastname.dev)
   and a proper Open Graph image make LinkedIn/Slack link previews look
   professional instead of generic.
2. **Make GitHub repos public and link them individually.** Right now
   project cards link to your GitHub profile as a placeholder — once
   individual repos for the RAG pipeline, ETL work samples, etc. are
   public, link `githubUrl` per project in `data.ts` directly to each repo.
3. **Add a few public, recruiter-skimmable side projects.** Enterprise
   work can't be open-sourced, but a small public repo (e.g. a mini RAG
   demo over open data, or a PySpark ETL sample on a public dataset)
   gives recruiters and hiring managers something to click into and
   verify hands-on skill.
4. **Pin your best repos on GitHub** and keep READMEs in each with a
   one-paragraph summary, setup steps, and a screenshot/GIF if it's
   visual — this is often the first thing a technical recruiter or
   hiring manager opens after the portfolio.
5. **Earn 1–2 cloud/GenAI certifications** (e.g. AWS/Azure/GCP associate
   level, or a recognized LLM/GenAI course) — they're cheap signal for
   recruiters doing keyword screening and ATS filtering, and the site
   already has a ready-made slot for them.
6. **Keep the LinkedIn headline and About section in sync** with the
   site's tagline and About copy — recruiters frequently cross-check
   both, and consistent positioning (e.g. "Data Engineer with GenAI
   specialization") reinforces a clear, memorable identity rather than
   a generic "data + AI + cloud" laundry list.
7. **Add metrics to project bullets wherever possible.** You already
   have strong ones (20M+ daily transactions, 65% runtime reduction,
   $250K+ savings) — for newer/ current work, start tracking similar
   numbers (latency improvements, accuracy/precision on RAG retrieval,
   cost savings from LLM optimization) so future updates keep that bar.
8. **Submit the sitemap to Google Search Console** after deploying, so
   the site gets indexed and shows up when recruiters search your name.

---

## 5. Tech notes

- **Dark mode by default** — no toggle is implemented since the brief
  specifies dark-by-default; the design token system in
  `tailwind.config.js` makes adding a light theme straightforward later
  if needed (swap `base`/`panel`/`ink` values behind a `:root[data-theme]`
  selector).
- **Animations respect `prefers-reduced-motion`** — see `globals.css`.
- **All interactive components are client components** (`"use client"`)
  only where they need hooks or Framer Motion; layout-only components
  (`Footer`, `Button`) stay server components for smaller client bundles.
- **The hero portrait** lives at `public/images/profile.png`. Swap this
  file (same filename, or update the `src` in `Hero.tsx`) to update the
  photo. It's paired with the animated pipeline strip — the page's
  signature visual motif — rather than shown alone.
