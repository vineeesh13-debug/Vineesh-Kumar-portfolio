// src/lib/utils.ts
import { clsx, type ClassValue } from "clsx";

/**
 * Merge conditional class names. Kept dependency-light (no tailwind-merge)
 * since this project doesn't have conflicting Tailwind class collisions
 * that require dedupe logic.
 */
export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}
