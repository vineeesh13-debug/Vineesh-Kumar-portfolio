// src/lib/data.ts
// -----------------------------------------------------------------------------
// SINGLE SOURCE OF TRUTH for all resume-derived content on the site.
// Every string in this file is derived from the uploaded resume
// (Vineesh Kumar — AI/ML/Data Engineer). Nothing here is fabricated:
// company names, dates, and achievements are taken directly from the
// resume; only phrasing/formatting has been adapted for a web audience.
// -----------------------------------------------------------------------------

export const profile = {
  name: "Vineesh Kumar",
  title: "AI / ML / Data Engineer",
  tagline:
    "Data engineer who builds the pipelines GenAI systems run on — from petabyte-scale ETL to production RAG.",
  email: "vineeesh13@gmail.com",
  phone: "302-553-6704",
  location: "United States",
  linkedin: "https://www.linkedin.com/in/vineesh1013",
  github: "https://github.com/vineeesh13-debug",
  githubHandle: "vineeesh13-debug",
  resumeFile: "/resume/Vineesh-Kumar-Resume.docx",
  yearsExperience: 7,
};

// -----------------------------------------------------------------------------
// ABOUT — recruiter-friendly rewrite of the professional summary.
// Source: resume "Professional Summary" bullet list.
// -----------------------------------------------------------------------------
export const about = {
  heading: "About",
  paragraphs: [
    "I'm an AI/ML/Data Engineer with 7+ years of experience designing, building, and optimizing large-scale, cloud-based data platforms — and, increasingly, the LLM and GenAI systems that sit on top of them.",
    "My core strength is the full data lifecycle: ingesting and transforming massive datasets with Spark, Databricks, and cloud-native ETL tools, then modeling them into warehouses and lakehouses (Snowflake, Synapse, BigQuery, Redshift) that BI teams and ML models can actually rely on. On top of that foundation, I build GenAI applications — RAG pipelines, LLM orchestration with LangChain and LlamaIndex, and safety-guarded production LLM apps using Guardrails.ai and TruLens.",
    "I've worked across regulated, high-volume environments — banking and healthcare-adjacent financial services — where reliability, governance, and cost control matter as much as raw capability. I'm comfortable owning a problem end-to-end: requirements gathering, pipeline architecture, model integration, deployment, and the dashboards that prove it's working.",
  ],
  highlights: [
    { label: "Years of experience", value: "7+" },
    { label: "Daily transactions processed in one pipeline", value: "20M+" },
    { label: "Query runtime reduction achieved", value: "65%" },
    { label: "Annual savings generated", value: "$250K+" },
  ],
};

// -----------------------------------------------------------------------------
// SKILLS — organized into recruiter-scannable categories.
// Source: resume "Technical Skills" section, regrouped into the categories
// requested (AI, ML, GenAI, LLMs, Data Engineering, Cloud, Databases, MLOps).
// -----------------------------------------------------------------------------
export type SkillCategory = {
  id: string;
  label: string;
  description: string;
  skills: string[];
};

export const skillCategories: SkillCategory[] = [
  {
    id: "ai",
    label: "Artificial Intelligence",
    description: "Core AI/NLP techniques applied across production systems.",
    skills: [
      "Natural Language Processing (NLP)",
      "Deep Learning",
      "Neural Networks",
      "RNN",
      "CNN",
      "Transformers",
      "Embedding Models",
      "Computer Vision",
    ],
  },
  {
    id: "ml",
    label: "Machine Learning",
    description: "Frameworks and libraries used across the ML lifecycle.",
    skills: [
      "TensorFlow",
      "PyTorch",
      "Keras",
      "Pandas / NumPy",
      "Feature Engineering",
      "Model Development & Evaluation",
      "Hugging Face",
    ],
  },
  {
    id: "genai",
    label: "Generative AI",
    description: "Building and safeguarding LLM-powered applications.",
    skills: [
      "Generative AI (GenAI)",
      "Retrieval-Augmented Generation (RAG)",
      "Prompt Engineering (Zero/Few-shot, CoT)",
      "LangChain",
      "LangGraph",
      "LlamaIndex",
      "Autogen",
      "Guardrails.ai",
      "TruLens",
      "PromptLayer",
      "FAISS",
    ],
  },
  {
    id: "llms",
    label: "LLMs",
    description: "Models and integration patterns for large language models.",
    skills: [
      "GPT-4 / GPT-3.5",
      "Claude 3.5",
      "LLaMA 3",
      "Mistral",
      "T5",
      "BERT / GPT-2",
      "OpenAI Function Calling & Tool Use",
      "Azure OpenAI API",
    ],
  },
  {
    id: "data-engineering",
    label: "Data Engineering",
    description: "Large-scale ETL/ELT, orchestration, and distributed processing.",
    skills: [
      "Apache Spark / PySpark / Spark-SQL",
      "Apache Airflow",
      "Apache Kafka",
      "Apache Beam",
      "Apache NiFi",
      "Apache Sqoop",
      "Hadoop / HiveQL / Presto",
      "AWS Glue (Studio, Workflows, Crawlers)",
      "Azure Data Factory & Mapping Data Flows",
      "Informatica PowerCenter",
      "Talend",
      "Matillion",
      "DBT",
    ],
  },
  {
    id: "cloud",
    label: "Cloud Platforms",
    description: "Multi-cloud experience across AWS, Azure, and GCP.",
    skills: [
      "AWS (EC2, S3, SageMaker, Lambda, Glue)",
      "Microsoft Azure (Databricks, Synapse, OpenAI, ADF, Blob Storage)",
      "Google Cloud Platform (Vertex AI, BigQuery)",
      "Azure Data Lake (ADLS)",
      "Terraform & CloudFormation (IaC)",
    ],
  },
  {
    id: "databases",
    label: "Databases",
    description: "Relational, NoSQL, and cloud data warehouse platforms.",
    skills: [
      "Snowflake",
      "BigQuery",
      "Redshift",
      "Azure Synapse",
      "PostgreSQL / MySQL / SQL Server",
      "Oracle",
      "MongoDB",
      "Cassandra",
      "DynamoDB",
      "HBase",
    ],
  },
  {
    id: "mlops",
    label: "DevOps / MLOps",
    description: "Deployment, orchestration, and lifecycle tooling.",
    skills: [
      "Docker",
      "Kubernetes",
      "MLflow",
      "DVC",
      "GitHub Actions",
      "Jenkins",
      "CI/CD",
      "Git",
      "Jira (Agile/Scrum)",
    ],
  },
];

// -----------------------------------------------------------------------------
// EXPERIENCE — chronological work history.
// Source: resume "Professional Experience" section, verbatim companies/dates,
// responsibilities condensed into achievement-style bullets.
// -----------------------------------------------------------------------------
export type ExperienceEntry = {
  id: string;
  company: string;
  role: string;
  location: string;
  duration: string;
  current?: boolean;
  achievements: string[];
  technologies: string[];
};

export const experience: ExperienceEntry[] = [
  {
    id: "mt-bank",
    company: "M&T Bank",
    role: "AI/ML/Data Engineer",
    location: "Buffalo, NY",
    duration: "Jan 2025 – Present",
    current: true,
    achievements: [
      "Developed and deployed GenAI models using TensorFlow, PyTorch, and OpenAI GPT APIs to automate text generation, improving productivity and decision-making for clients across industries.",
      "Implemented hybrid semantic + keyword search with embedding rerankers, integrating LlamaIndex for document ingestion, parsing, and chunk-based retrieval.",
      "Built Retrieval-Augmented Generation (RAG) pipelines using OpenAI embeddings and FAISS for internal knowledge management.",
      "Applied Guardrails.ai to ensure LLM safety, structural control, and hallucination mitigation in customer-facing GenAI applications.",
      "Used LangChain and LlamaIndex to orchestrate custom LLM workflows integrated with enterprise document repositories.",
      "Leveraged OpenAI Function Calling and Tool Use APIs to enable dynamic multi-step reasoning and workflow automation in internal systems.",
      "Configured the OpenShift GPU Operator to orchestrate hardware acceleration for deep learning workloads on TensorFlow and PyTorch.",
      "Built scalable PySpark transformation jobs in Azure Databricks, implementing Delta Lake ACID transactions for CDC.",
      "Modeled analytical datasets in Azure Synapse Analytics, optimizing star schemas to support BI and churn-prediction queries.",
      "Optimized Snowflake performance through partition pruning, clustering keys, and query profiling, improving dashboard load time.",
    ],
    technologies: [
      "TensorFlow",
      "PyTorch",
      "OpenAI API",
      "LangChain",
      "LlamaIndex",
      "FAISS",
      "Guardrails.ai",
      "Azure Databricks",
      "Delta Lake",
      "Azure Synapse",
      "Snowflake",
      "Apache Airflow",
      "MongoDB",
      "OpenShift",
    ],
  },
  {
    id: "wintrust",
    company: "Wintrust Financial",
    role: "Azure Data Engineer",
    location: "Rosemont, IL",
    duration: "Dec 2022 – Dec 2024",
    achievements: [
      "Designed and optimized enterprise-grade ETL pipelines with Azure Data Factory, Databricks, and Delta Lake to process 20M+ pharmacy transactions daily, improving SLA adherence by 35%.",
      "Migrated critical reporting workflows from legacy SQL Server to Snowflake and Synapse, cutting query runtimes by 65% and generating $250K+ in annual savings.",
      "Developed Spark jobs (Scala, Spark-SQL/Streaming) to clean and prepare data feeds for Hive-based analysis, including custom input formats for non-standard file types.",
      "Built PySpark jobs running on a Kubernetes cluster for faster, horizontally-scaled data processing.",
      "Designed Data Marts using star and snowflake dimensional modeling schemas.",
      "Implemented Slowly Changing Dimension (SCD) ETL logic to maintain historical accuracy in the data warehouse.",
      "Led migration strategy for legacy systems onto Azure (Lift-and-Shift / Azure Migrate), working across ADLS, ADF v2, Azure SQL DW, Service Bus, Key Vault, and Azure Analysis Services.",
      "Automated and validated data pipelines using Apache Airflow, with Kafka used for log and event-stream ingestion.",
      "Developed Power BI and Tableau dashboards, including filters, parameters, and calculated sets for business reporting.",
    ],
    technologies: [
      "Azure Data Factory",
      "Azure Databricks",
      "Delta Lake",
      "Snowflake",
      "Azure Synapse",
      "Spark / Scala",
      "PySpark",
      "Kubernetes",
      "Apache Kafka",
      "Apache Airflow",
      "Hive",
      "Power BI",
      "Tableau",
    ],
  },
  {
    id: "techasoft",
    company: "Techasoft Pvt. Ltd.",
    role: "Data Scientist",
    location: "India",
    duration: "May 2019 – Jul 2022",
    achievements: [
      "Developed Apache Spark jobs in Scala for high-throughput data processing, replacing standard MapReduce workflows for performance-critical pipelines.",
      "Designed healthcare data warehousing solutions in Snowflake, including data cleansing, surrogate key generation, SCD Type 2 handling, and CDC for clinical and financial analytics.",
      "Built dynamic tables in Snowflake to replace traditional stored procedures, simplifying transformation logic and improving load times.",
      "Automated end-to-end pipelines using Apache Airflow and DAGs for reliable orchestration of distributed workloads.",
      "Configured Kafka brokers and topics to pipeline server log data into Spark Streaming for downstream analytics.",
      "Created encrypted, access-controlled data lakes on AWS S3, with Airflow scheduling for ingestion into Snowflake.",
      "Implemented batch and streaming load pipelines using Snowpipe and Matillion from AWS S3-based data lakes.",
      "Worked within an Agile/Scrum environment, participating in sprint planning and iterative review cycles.",
    ],
    technologies: [
      "Apache Spark",
      "Scala",
      "Snowflake",
      "Apache Airflow",
      "Apache Kafka",
      "AWS S3",
      "Snowpipe",
      "Matillion",
      "Hive",
      "MapReduce",
    ],
  },
];

// -----------------------------------------------------------------------------
// PROJECTS — derived from concrete, resume-stated work (not fabricated).
// Each project maps directly to achievements described in the experience
// section above. GitHub/demo links are placeholders pending public repos.
// -----------------------------------------------------------------------------
export type Project = {
  id: string;
  name: string;
  context: string; // where this work happened
  problem: string;
  solution: string;
  technologies: string[];
  githubUrl?: string;
  demoUrl?: string;
};

export const projects: Project[] = [
  {
    id: "rag-knowledge-management",
    name: "Enterprise RAG Knowledge Pipeline",
    context: "M&T Bank",
    problem:
      "Internal teams needed fast, accurate answers from large, fragmented enterprise document repositories — standard keyword search wasn't surfacing the right context, and hallucination risk made raw LLM answers unsafe to ship to customer-facing teams.",
    solution:
      "Built a Retrieval-Augmented Generation pipeline using OpenAI embeddings and FAISS for vector search, with LlamaIndex handling document ingestion, parsing, and chunk-based retrieval. Layered in hybrid semantic + keyword search with embedding rerankers, and applied Guardrails.ai to enforce output structure and reduce hallucinations before responses reached end users.",
    technologies: [
      "LangChain",
      "LlamaIndex",
      "OpenAI Embeddings",
      "FAISS",
      "Guardrails.ai",
      "Python",
    ],
    githubUrl: "https://github.com/vineeesh13-debug",
  },
  {
    id: "llm-workflow-automation",
    name: "LLM Tool-Use Workflow Automation",
    context: "M&T Bank",
    problem:
      "Multi-step internal workflows — gathering data, reasoning over it, and taking action — were manual and slow, with no consistent way for an LLM to safely call internal systems.",
    solution:
      "Leveraged OpenAI Function Calling and Tool Use APIs to enable dynamic, multi-step reasoning and automated workflow execution from LLMs, orchestrated through LangChain. Integrated with GPU-accelerated deep learning workloads via an OpenShift GPU Operator to support TensorFlow and PyTorch inference at scale.",
    technologies: [
      "OpenAI Function Calling",
      "LangChain",
      "TensorFlow",
      "PyTorch",
      "OpenShift",
    ],
    githubUrl: "https://github.com/vineeesh13-debug",
  },
  {
    id: "pharmacy-etl-modernization",
    name: "High-Volume Pharmacy ETL Modernization",
    context: "Wintrust Financial",
    problem:
      "Legacy SQL Server-based reporting couldn't keep pace with 20M+ daily pharmacy transactions, causing SLA misses and slow, expensive queries for downstream BI consumers.",
    solution:
      "Designed and optimized enterprise-grade ETL pipelines using Azure Data Factory, Databricks, and Delta Lake to process the full daily transaction volume reliably, improving SLA adherence by 35%. Migrated reporting workloads to Snowflake and Synapse, cutting query runtimes by 65% and generating $250K+ in annual savings.",
    technologies: [
      "Azure Data Factory",
      "Azure Databricks",
      "Delta Lake",
      "Snowflake",
      "Azure Synapse",
      "PySpark",
    ],
    githubUrl: "https://github.com/vineeesh13-debug",
  },
  {
    id: "snowflake-healthcare-warehouse",
    name: "Snowflake Healthcare Data Warehouse",
    context: "Techasoft Pvt. Ltd.",
    problem:
      "Clinical and financial analytics required a reliable historical record of changing source data, but legacy stored-procedure-based transformations were brittle and slow to maintain.",
    solution:
      "Designed a Snowflake-based healthcare data warehouse with surrogate key generation, SCD Type 2 handling, and CDC implementations to preserve historical accuracy. Replaced stored procedures with dynamic Snowflake tables to simplify transformation logic and improve load performance, with Airflow DAGs orchestrating the full pipeline from S3-based data lakes via Snowpipe and Matillion.",
    technologies: [
      "Snowflake",
      "Apache Airflow",
      "AWS S3",
      "Snowpipe",
      "Matillion",
      "Apache Kafka",
    ],
    githubUrl: "https://github.com/vineeesh13-debug",
  },
];

// -----------------------------------------------------------------------------
// EDUCATION
// Source: resume "Education" section, verbatim.
// -----------------------------------------------------------------------------
export type EducationEntry = {
  id: string;
  degree: string;
  institution: string;
  year: string;
};

export const education: EducationEntry[] = [
  {
    id: "wilmington",
    degree: "M.S. in Information Systems Technology",
    institution: "Wilmington University",
    year: "2024",
  },
  {
    id: "anurag",
    degree: "B.E. in Electronics and Computer Science",
    institution: "Anurag Group of Institutions / Anurag University",
    year: "2020",
  },
];

// -----------------------------------------------------------------------------
// CERTIFICATIONS
// NOTE: The source resume does not list a dedicated certifications section.
// Per instructions not to fabricate credentials, this array intentionally
// starts empty. The Certifications section on the site renders a clean
// "coming soon" state rather than inventing entries. Add real certifications
// here as objects of this shape when available:
// { id, name, issuer, year, credentialUrl }
// -----------------------------------------------------------------------------
export type Certification = {
  id: string;
  name: string;
  issuer: string;
  year: string;
  credentialUrl?: string;
};

export const certifications: Certification[] = [];

// -----------------------------------------------------------------------------
// NAV
// -----------------------------------------------------------------------------
export const navLinks = [
  { href: "#about", label: "About" },
  { href: "#skills", label: "Skills" },
  { href: "#experience", label: "Experience" },
  { href: "#projects", label: "Projects" },
  { href: "#education", label: "Education" },
  { href: "#contact", label: "Contact" },
];
