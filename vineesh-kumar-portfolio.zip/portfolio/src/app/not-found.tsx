// src/app/not-found.tsx
import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-base px-6 text-center">
      <p className="eyebrow mb-4">404</p>
      <h1 className="font-display text-3xl font-semibold text-ink sm:text-4xl">
        This route doesn&apos;t exist in the pipeline.
      </h1>
      <p className="mt-3 max-w-md text-ink-muted">
        The page you&apos;re looking for was either moved or never ingested.
      </p>
      <Link
        href="/"
        className="mt-8 inline-flex items-center rounded-lg bg-signal px-5 py-2.5 text-sm font-medium text-base transition-colors hover:bg-signal-dim"
      >
        Back to home
      </Link>
    </div>
  );
}
