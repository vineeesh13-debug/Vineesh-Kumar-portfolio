// src/components/layout/Footer.tsx
import { Github, Linkedin, Mail } from "lucide-react";
import { profile, navLinks } from "@/lib/data";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border-soft">
      <div className="container-x py-12">
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="font-display text-lg font-semibold text-ink">
              {profile.name}
            </p>
            <p className="mt-1 max-w-xs text-sm text-ink-muted">
              {profile.title} — building data and GenAI systems that hold up
              in production.
            </p>
          </div>

          <div className="flex gap-10">
            <div>
              <p className="eyebrow mb-3 text-[10px]">Navigate</p>
              <ul className="space-y-2">
                {navLinks.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="text-sm text-ink-muted transition-colors hover:text-signal"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <p className="eyebrow mb-3 text-[10px]">Connect</p>
              <ul className="space-y-2">
                <li>
                  <a
                    href={`mailto:${profile.email}`}
                    className="flex items-center gap-2 text-sm text-ink-muted transition-colors hover:text-signal"
                  >
                    <Mail size={14} /> Email
                  </a>
                </li>
                <li>
                  <a
                    href={profile.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm text-ink-muted transition-colors hover:text-signal"
                  >
                    <Linkedin size={14} /> LinkedIn
                  </a>
                </li>
                <li>
                  <a
                    href={profile.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm text-ink-muted transition-colors hover:text-signal"
                  >
                    <Github size={14} /> GitHub
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-2 border-t border-border-soft pt-6 text-xs text-ink-faint sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {profile.name}. All rights reserved.
          </p>
          <p className="font-mono">Built with Next.js, TypeScript &amp; Tailwind CSS</p>
        </div>
      </div>
    </footer>
  );
}
