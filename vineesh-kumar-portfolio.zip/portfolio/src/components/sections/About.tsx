// src/components/sections/About.tsx
"use client";

import { motion } from "framer-motion";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { about } from "@/lib/data";

export function About() {
  return (
    <section id="about" className="container-x py-24 sm:py-32">
      <SectionHeading
        eyebrow="01 · About"
        title="I build the systems data and AI run on."
      />

      <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-5">
          {about.paragraphs.map((p, i) => (
            <motion.p
              key={i}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="leading-relaxed text-ink-muted"
            >
              {p}
            </motion.p>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-2 gap-4 self-start"
        >
          {about.highlights.map((stat) => (
            <div key={stat.label} className="panel p-5">
              <p className="font-display text-2xl font-semibold text-signal sm:text-3xl">
                {stat.value}
              </p>
              <p className="mt-1 text-xs leading-snug text-ink-faint">
                {stat.label}
              </p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
