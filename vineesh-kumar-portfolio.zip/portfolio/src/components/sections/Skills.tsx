// src/components/sections/Skills.tsx
"use client";

import { motion } from "framer-motion";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { skillCategories } from "@/lib/data";

export function Skills() {
  return (
    <section id="skills" className="container-x py-24 sm:py-32">
      <SectionHeading
        eyebrow="02 · Skills"
        title="Across the stack — from raw data to deployed LLM."
        description="Organized by where each tool sits in the lifecycle: understanding language and data, building models, shipping GenAI, moving data at scale, and keeping it all running."
      />

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {skillCategories.map((category, i) => (
          <motion.div
            key={category.id}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.4, delay: (i % 3) * 0.06 }}
            className="panel flex flex-col p-6 transition-colors duration-300 hover:border-signal/30"
          >
            <h3 className="font-display text-base font-semibold text-ink">
              {category.label}
            </h3>
            <p className="mt-1 text-xs text-ink-faint">
              {category.description}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {category.skills.map((skill) => (
                <span key={skill} className="tag hover:border-signal/40 hover:text-signal">
                  {skill}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
