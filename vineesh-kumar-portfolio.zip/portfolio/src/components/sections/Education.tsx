// src/components/sections/Education.tsx
"use client";

import { motion } from "framer-motion";
import { GraduationCap, Award } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { education, certifications } from "@/lib/data";

export function Education() {
  return (
    <section id="education" className="container-x py-24 sm:py-32">
      <SectionHeading eyebrow="05 · Education" title="Foundation." />

      <div className="grid gap-10 lg:grid-cols-2">
        {/* Education */}
        <div className="space-y-4">
          {education.map((entry, i) => (
            <motion.div
              key={entry.id}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.45, delay: i * 0.08 }}
              className="panel flex items-start gap-4 p-5"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-panel-raised text-signal">
                <GraduationCap size={18} />
              </div>
              <div>
                <p className="font-display text-base font-semibold text-ink">
                  {entry.degree}
                </p>
                <p className="mt-0.5 text-sm text-ink-muted">
                  {entry.institution}
                </p>
                <p className="mt-1 font-mono text-xs text-ink-faint">
                  {entry.year}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Certifications */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.45 }}
        >
          <p className="eyebrow mb-4">Certifications</p>
          {certifications.length > 0 ? (
            <div className="space-y-4">
              {certifications.map((cert) => (
                <div key={cert.id} className="panel flex items-start gap-4 p-5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-panel-raised text-amber">
                    <Award size={18} />
                  </div>
                  <div>
                    <p className="font-display text-base font-semibold text-ink">
                      {cert.name}
                    </p>
                    <p className="mt-0.5 text-sm text-ink-muted">
                      {cert.issuer}
                    </p>
                    <p className="mt-1 font-mono text-xs text-ink-faint">
                      {cert.year}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="panel flex items-start gap-4 p-5 border-dashed">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-panel-raised text-ink-faint">
                <Award size={18} />
              </div>
              <div>
                <p className="text-sm text-ink-muted">
                  Certifications in progress — actively pursuing credentials
                  in cloud and GenAI platforms. Check back soon, or ask
                  directly via the contact section.
                </p>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
}
