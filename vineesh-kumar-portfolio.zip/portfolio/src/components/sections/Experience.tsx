// src/components/sections/Experience.tsx
"use client";

import { motion } from "framer-motion";
import { MapPin, Calendar } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { experience } from "@/lib/data";

/**
 * Experience rendered as pipeline stages rather than a generic dotted
 * timeline. The connecting rail + stage markers mirror the Hero's
 * pipeline motif, which is appropriate here: this really is a sequence
 * — each role builds on the data/AI maturity of the last.
 */
export function Experience() {
  return (
    <section id="experience" className="container-x py-24 sm:py-32">
      <SectionHeading
        eyebrow="03 · Experience"
        title="Roles in sequence — each one going deeper into AI."
      />

      <div className="relative">
        {/* Continuous rail */}
        <div
          aria-hidden="true"
          className="absolute left-[15px] top-2 hidden h-[calc(100%-2rem)] w-px sm:block"
        >
          <svg width="2" height="100%" viewBox="0 0 2 100" preserveAspectRatio="none" className="h-full w-full">
            <line x1="1" y1="0" x2="1" y2="100" stroke="#1C2433" strokeWidth="2" />
          </svg>
        </div>

        <div className="space-y-10">
          {experience.map((role, i) => (
            <motion.div
              key={role.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: 0.05 }}
              className="relative pl-0 sm:pl-12"
            >
              {/* Stage marker */}
              <div className="absolute left-0 top-1.5 hidden h-8 w-8 items-center justify-center sm:flex">
                <span
                  className={`flex h-3 w-3 rounded-full ${
                    role.current
                      ? "bg-signal shadow-[0_0_0_4px_rgba(94,234,212,0.15)]"
                      : "bg-ink-faint"
                  }`}
                />
              </div>

              <div className="panel p-6 sm:p-7">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-display text-lg font-semibold text-ink sm:text-xl">
                        {role.role}
                      </h3>
                      {role.current && (
                        <span className="tag border-signal/40 text-signal">
                          current
                        </span>
                      )}
                    </div>
                    <p className="mt-1 font-medium text-signal">
                      {role.company}
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-col gap-1 text-xs text-ink-faint sm:items-end">
                    <span className="flex items-center gap-1.5">
                      <Calendar size={12} /> {role.duration}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin size={12} /> {role.location}
                    </span>
                  </div>
                </div>

                <ul className="mt-5 space-y-2.5">
                  {role.achievements.map((item, idx) => (
                    <li
                      key={idx}
                      className="flex gap-3 text-sm leading-relaxed text-ink-muted"
                    >
                      <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-signal/60" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>

                <div className="mt-5 flex flex-wrap gap-2 border-t border-border-soft pt-5">
                  {role.technologies.map((tech) => (
                    <span key={tech} className="tag">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
