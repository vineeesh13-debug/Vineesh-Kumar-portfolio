// src/components/sections/Contact.tsx
"use client";

import { motion } from "framer-motion";
import { Mail, Linkedin, Github, Phone } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Button } from "@/components/ui/Button";
import { profile } from "@/lib/data";

export function Contact() {
  return (
    <section id="contact" className="container-x py-24 sm:py-32">
      <SectionHeading
        eyebrow="06 · Contact"
        title="Let's talk about your data and AI roadmap."
        description="Open to AI/ML Engineer, Data Engineer, and GenAI Engineer roles. The fastest way to reach me is email or LinkedIn."
      />

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-60px" }}
        transition={{ duration: 0.5 }}
        className="panel grid gap-px overflow-hidden sm:grid-cols-3"
      >
        <a
          href={`mailto:${profile.email}`}
          className="group flex flex-col gap-3 p-7 transition-colors hover:bg-panel-raised"
        >
          <Mail size={20} className="text-signal" />
          <div>
            <p className="font-display text-sm font-semibold text-ink">
              Email
            </p>
            <p className="mt-1 break-all text-xs text-ink-muted group-hover:text-signal">
              {profile.email}
            </p>
          </div>
        </a>

        <a
          href={profile.linkedin}
          target="_blank"
          rel="noopener noreferrer"
          className="group flex flex-col gap-3 p-7 transition-colors hover:bg-panel-raised sm:border-x sm:border-border-soft"
        >
          <Linkedin size={20} className="text-signal" />
          <div>
            <p className="font-display text-sm font-semibold text-ink">
              LinkedIn
            </p>
            <p className="mt-1 text-xs text-ink-muted group-hover:text-signal">
              in/vineesh1013
            </p>
          </div>
        </a>

        <a
          href={profile.github}
          target="_blank"
          rel="noopener noreferrer"
          className="group flex flex-col gap-3 p-7 transition-colors hover:bg-panel-raised"
        >
          <Github size={20} className="text-signal" />
          <div>
            <p className="font-display text-sm font-semibold text-ink">
              GitHub
            </p>
            <p className="mt-1 text-xs text-ink-muted group-hover:text-signal">
              {profile.githubHandle}
            </p>
          </div>
        </a>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.15 }}
        className="mt-8 flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between"
      >
        <p className="flex items-center gap-2 text-sm text-ink-faint">
          <Phone size={14} /> {profile.phone}
        </p>
        <Button href={`mailto:${profile.email}`} icon={<Mail size={16} />}>
          Send a message
        </Button>
      </motion.div>
    </section>
  );
}
