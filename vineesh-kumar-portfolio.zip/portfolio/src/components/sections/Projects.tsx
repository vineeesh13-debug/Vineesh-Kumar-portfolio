// src/components/sections/Projects.tsx
"use client";

import { motion } from "framer-motion";
import { Github, ExternalLink, Building2 } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { projects } from "@/lib/data";

export function Projects() {
  return (
    <section id="projects" className="container-x py-24 sm:py-32">
      <SectionHeading
        eyebrow="04 · Featured Projects"
        title="Real systems, built on the job."
        description="Each of these maps to work delivered in a professional role — no demo-ware. GitHub links point to my profile while individual repos are being made public."
      />

      <div className="grid gap-6 sm:grid-cols-2">
        {projects.map((project, i) => (
          <motion.article
            key={project.id}
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: (i % 2) * 0.08 }}
            className="panel flex flex-col p-6 transition-colors duration-300 hover:border-signal/30 sm:p-7"
          >
            <div className="flex items-center gap-2 text-xs text-ink-faint">
              <Building2 size={13} />
              <span>{project.context}</span>
            </div>

            <h3 className="mt-3 font-display text-xl font-semibold text-ink">
              {project.name}
            </h3>

            <div className="mt-4 space-y-3">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-amber/80">
                  Problem
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-muted">
                  {project.problem}
                </p>
              </div>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-signal">
                  Solution
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-muted">
                  {project.solution}
                </p>
              </div>
            </div>

            <div className="mt-5 flex flex-wrap gap-2">
              {project.technologies.map((tech) => (
                <span key={tech} className="tag">
                  {tech}
                </span>
              ))}
            </div>

            <div className="mt-6 flex gap-3 border-t border-border-soft pt-5">
              {project.githubUrl && (
                <a
                  href={project.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs font-medium text-ink-muted transition-colors hover:text-signal"
                >
                  <Github size={14} /> Repository
                </a>
              )}
              {project.demoUrl ? (
                <a
                  href={project.demoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs font-medium text-ink-muted transition-colors hover:text-signal"
                >
                  <ExternalLink size={14} /> Live demo
                </a>
              ) : (
                <span className="flex items-center gap-1.5 text-xs font-medium text-ink-faint">
                  <ExternalLink size={14} /> Demo coming soon
                </span>
              )}
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
