// src/components/sections/Hero.tsx
"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { Download, Github, Linkedin, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { profile } from "@/lib/data";

const pipelineStages = ["Ingest", "Transform", "Model", "Serve"];

/**
 * Hero — the thesis of the page. The visual column pairs a portrait with
 * a compact, literal pipeline diagram: data flowing through Ingest →
 * Transform → Model → Serve, which is the actual shape of this person's
 * day-to-day work rather than a generic decorative graphic.
 */
export function Hero() {
  return (
    <section className="relative flex min-h-screen flex-col justify-center overflow-hidden pt-24">
      {/* Faint grid backdrop, fading toward the bottom */}
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-grid-pattern bg-[size:48px_48px] opacity-[0.15] [mask-image:linear-gradient(to_bottom,black,transparent)]"
      />

      <div className="container-x relative z-10 grid gap-16 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
        {/* Copy column */}
        <div>
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="eyebrow mb-5"
          >
            {profile.location} · Available for new roles
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.05 }}
            className="font-display text-4xl font-semibold leading-[1.05] tracking-tight text-ink sm:text-5xl md:text-6xl"
          >
            {profile.name}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.12 }}
            className="mt-3 font-display text-xl font-medium text-signal sm:text-2xl"
          >
            {profile.title}
          </motion.p>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.18 }}
            className="mt-6 max-w-xl text-balance text-lg leading-relaxed text-ink-muted"
          >
            {profile.tagline} 7+ years turning messy, large-scale data into
            warehouses, dashboards, and LLM applications that businesses
            actually run on.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.26 }}
            className="mt-9 flex flex-wrap items-center gap-3"
          >
            <Button href={profile.resumeFile} download icon={<Download size={16} />}>
              Download Resume
            </Button>
            <Button
              href={profile.github}
              target="_blank"
              rel="noopener noreferrer"
              variant="secondary"
              icon={<Github size={16} />}
            >
              GitHub
            </Button>
            <Button
              href={profile.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              variant="secondary"
              icon={<Linkedin size={16} />}
            >
              LinkedIn
            </Button>
          </motion.div>
        </div>

        {/* Visual column: portrait + compact pipeline strip */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="relative"
        >
          <div className="panel relative overflow-hidden">
            {/* Portrait */}
            <div className="relative aspect-[4/5] w-full overflow-hidden">
              <Image
                src="/images/profile.png"
                alt={`${profile.name}, ${profile.title}`}
                fill
                priority
                sizes="(min-width: 1024px) 35vw, 80vw"
                className="object-cover"
              />
              {/* Subtle gradient so the panel content below reads cleanly */}
              <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-panel to-transparent" />
              {/* Corner accent — small, single deliberate flourish */}
              <span className="absolute right-4 top-4 h-2 w-2 rounded-full bg-signal shadow-[0_0_0_4px_rgba(94,234,212,0.18)]" />
            </div>

            {/* Compact pipeline strip */}
            <div className="border-t border-border-soft p-5 sm:p-6">
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-faint">
                current pipeline
              </p>
              <div className="mt-4 flex items-center justify-between">
                {pipelineStages.map((stage, i) => (
                  <div key={stage} className="flex flex-1 items-center">
                    <div className="flex flex-col items-center gap-1.5 text-center">
                      <div className="relative flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-signal/40 bg-panel-raised font-mono text-[10px] text-signal">
                        {i + 1}
                        {i === 1 && (
                          <span className="absolute inset-0 rounded-full border border-signal/60 animate-pulse-slow" />
                        )}
                      </div>
                      <span className="font-mono text-[10px] text-ink-muted">
                        {stage}
                      </span>
                    </div>
                    {i < pipelineStages.length - 1 && (
                      <div className="mx-1 h-px flex-1 overflow-hidden self-start mt-3.5">
                        <svg width="100%" height="2" viewBox="0 0 24 2" preserveAspectRatio="none" className="h-full w-full">
                          <line x1="0" y1="1" x2="24" y2="1" stroke="#1C2433" strokeWidth="2" />
                          <line
                            x1="0"
                            y1="1"
                            x2="24"
                            y2="1"
                            stroke="#5EEAD4"
                            strokeWidth="2"
                            strokeDasharray="3 5"
                            className="flow-dash"
                            opacity="0.6"
                          />
                        </svg>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <div className="mt-5 grid grid-cols-2 gap-3 border-t border-border-soft pt-4 font-mono text-[10px] text-ink-faint">
                <span>spark · airflow · kafka</span>
                <span className="text-right">langchain · faiss · rag</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      <motion.a
        href="#about"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.6 }}
        className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-ink-faint transition-colors hover:text-signal sm:flex"
        aria-label="Scroll to About section"
      >
        <span className="font-mono text-[10px] uppercase tracking-[0.2em]">
          Scroll
        </span>
        <ArrowDown size={14} className="animate-bounce" />
      </motion.a>
    </section>
  );
}
