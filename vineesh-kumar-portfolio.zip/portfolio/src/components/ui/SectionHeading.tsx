// src/components/ui/SectionHeading.tsx
"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

type SectionHeadingProps = {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  children?: ReactNode;
};

/**
 * Standard section header: mono eyebrow label, display heading, optional
 * supporting copy. The eyebrow encodes the section's role (e.g. "02 —
 * Pipeline stages" reads as a real stage label, not decoration) and
 * animates in on scroll for a calm, consistent rhythm between sections.
 */
export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  children,
}: SectionHeadingProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        "mb-12 max-w-2xl",
        align === "center" && "mx-auto text-center"
      )}
    >
      <p className="eyebrow mb-3">{eyebrow}</p>
      <h2 className="section-heading text-balance">{title}</h2>
      {description && (
        <p className="mt-4 text-ink-muted leading-relaxed">{description}</p>
      )}
      {children}
    </motion.div>
  );
}
