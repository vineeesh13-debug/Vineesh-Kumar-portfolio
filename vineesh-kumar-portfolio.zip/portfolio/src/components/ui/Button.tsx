// src/components/ui/Button.tsx
import Link from "next/link";
import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

type ButtonVariant = "primary" | "secondary" | "ghost";

type CommonProps = {
  children: ReactNode;
  variant?: ButtonVariant;
  icon?: ReactNode;
  className?: string;
};

type ButtonAsLink = CommonProps & {
  href: string;
  target?: string;
  rel?: string;
  download?: boolean | string;
  onClick?: never;
};

type ButtonAsButton = CommonProps & {
  href?: never;
  onClick?: () => void;
  type?: "button" | "submit";
};

type ButtonProps = ButtonAsLink | ButtonAsButton;

const variantClasses: Record<ButtonVariant, string> = {
  primary:
    "bg-signal text-base hover:bg-signal-dim shadow-[0_0_0_1px_rgba(94,234,212,0.3)]",
  secondary:
    "bg-panel-raised text-ink border border-border hover:border-signal/40 hover:text-signal",
  ghost: "bg-transparent text-ink-muted hover:text-ink",
};

/**
 * Shared button/link control. Renders as a Next.js Link when `href` is
 * provided, otherwise as a native button — keeps call sites simple
 * (e.g. "Download Resume" vs. a future client-side action) without two
 * components to maintain.
 */
export function Button(props: ButtonProps) {
  const { children, variant = "primary", icon, className } = props;

  const classes = cn(
    "inline-flex items-center gap-2 rounded-lg px-5 py-2.5 font-body text-sm font-medium transition-all duration-200",
    variantClasses[variant],
    className
  );

  if ("href" in props && props.href) {
    return (
      <Link
        href={props.href}
        target={props.target}
        rel={props.rel}
        download={props.download}
        className={classes}
      >
        {children}
        {icon}
      </Link>
    );
  }

  return (
    <button
      type={(props as ButtonAsButton).type ?? "button"}
      onClick={(props as ButtonAsButton).onClick}
      className={classes}
    >
      {children}
      {icon}
    </button>
  );
}
