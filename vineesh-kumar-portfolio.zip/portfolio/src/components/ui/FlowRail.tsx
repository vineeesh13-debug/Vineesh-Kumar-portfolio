// src/components/ui/FlowRail.tsx
"use client";

/**
 * Signature visual motif for the page: a vertical "pipeline rail" with a
 * pulsing node, used between major sections. It's a literal nod to the
 * subject's actual work (data moving through orchestrated stages) rather
 * than a generic decorative divider — the dash animation reads as data
 * actively flowing downward through the page.
 */
export function FlowRail() {
  return (
    <div
      aria-hidden="true"
      className="relative mx-auto h-16 w-px overflow-hidden sm:h-24"
    >
      <svg
        width="2"
        height="100%"
        viewBox="0 0 2 100"
        preserveAspectRatio="none"
        className="absolute inset-0 h-full w-full"
      >
        <line
          x1="1"
          y1="0"
          x2="1"
          y2="100"
          stroke="#1C2433"
          strokeWidth="2"
        />
        <line
          x1="1"
          y1="0"
          x2="1"
          y2="100"
          stroke="#5EEAD4"
          strokeWidth="2"
          strokeDasharray="6 10"
          className="flow-dash"
          opacity="0.7"
        />
      </svg>
    </div>
  );
}
